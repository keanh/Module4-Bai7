create view vw_ctpnhap_loc as
select `bai_tap`.`ctpnhap`.`SOPN`        AS `SOPN`,
       `bai_tap`.`ctpnhap`.`MAVTU`       AS `MAVTU`,
       `bai_tap`.`ctpnhap`.`SLNHAP`      AS `SLNHAP`,
       `bai_tap`.`ctpnhap`.`DGNHAP`      AS `DGNHAP`,
       sum(`bai_tap`.`ctpnhap`.`DGNHAP`) AS `sum(DGNHAP)`
from `bai_tap`.`ctpnhap`
where (`bai_tap`.`ctpnhap`.`SLNHAP` > 5)
group by `bai_tap`.`ctpnhap`.`MAVTU`;

