create
    definer = root@localhost procedure them_don_dat_hang(IN sodh int, IN ngaydh date, IN manhacc int)
BEGIN
  insert into DONDH values(sodh,ngaydh,manhacc);
END;

