create
    definer = root@localhost procedure them_chi_tiet_don_dat_hang(IN sodh int, IN mavtu varchar(15), IN sldat int)
BEGIN
  insert into CTDONDH values(sodh,mavtu,sldat);
END;

