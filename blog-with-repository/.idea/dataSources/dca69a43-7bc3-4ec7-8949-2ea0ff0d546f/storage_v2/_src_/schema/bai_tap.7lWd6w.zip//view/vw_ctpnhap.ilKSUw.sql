create view vw_ctpnhap as
select `bai_tap`.`ctpnhap`.`SOPN`        AS `SOPN`,
       `bai_tap`.`ctpnhap`.`MAVTU`       AS `MAVTU`,
       `bai_tap`.`ctpnhap`.`SLNHAP`      AS `SLNHAP`,
       `bai_tap`.`ctpnhap`.`DGNHAP`      AS `DGNHAP`,
       sum(`bai_tap`.`ctpnhap`.`DGNHAP`) AS `sum(DGNHAP)`
from `bai_tap`.`ctpnhap`
group by `bai_tap`.`ctpnhap`.`MAVTU`;

