create
    definer = root@localhost procedure new_procedure(IN mavtu varchar(15))
BEGIN
select SLCUOI from TONKHO where MAVTU = mavtu;
END;

