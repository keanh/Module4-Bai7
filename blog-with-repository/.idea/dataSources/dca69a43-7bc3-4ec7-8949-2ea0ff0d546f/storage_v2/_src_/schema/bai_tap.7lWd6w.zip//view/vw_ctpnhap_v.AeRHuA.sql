create view vw_ctpnhap_v as
select `bai_tap`.`ctpnhap`.`SOPN`        AS `SOPN`,
       `bai_tap`.`vattu`.`MAVTU`         AS `MAVTU`,
       `bai_tap`.`vattu`.`TENVTU`        AS `TENVTU`,
       `bai_tap`.`ctpnhap`.`SLNHAP`      AS `SLNHAP`,
       `bai_tap`.`ctpnhap`.`DGNHAP`      AS `DGNHAP`,
       sum(`bai_tap`.`ctpnhap`.`DGNHAP`) AS `sum(DGNHAP)`
from (`bai_tap`.`ctpnhap`
         join `bai_tap`.`vattu` on ((`bai_tap`.`ctpnhap`.`MAVTU` = `bai_tap`.`vattu`.`MAVTU`)))
group by `bai_tap`.`vattu`.`TENVTU`;

