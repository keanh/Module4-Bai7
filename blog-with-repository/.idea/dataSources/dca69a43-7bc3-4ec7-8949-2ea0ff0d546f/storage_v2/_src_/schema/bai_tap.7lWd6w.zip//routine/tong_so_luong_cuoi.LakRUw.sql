create
    definer = root@localhost procedure tong_so_luong_cuoi(IN mavtu1 varchar(15))
BEGIN
select SLCUOI from tonkho where MAVTU = mavtu1;  
END;

